package net.isetjb.tp4;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
public class Application
{
	private static SessionFactory factory;
	public static void main(String[] args)
	{
		// Open connection pool
		factory = HibernateUtil.getSessionFactory();
		// CRUD calls examples
		
		List<Category> lc = new ArrayList<Category>();
		
		Category c1 = new Category();
		c1.setName("Stylo � bille");
		
		Category c2 = new Category();
		c2.setName("Stylo � encre");
		Category c3 = new Category();
		c3.setName("feutre");
		
		lc.add(c1);
		lc.add(c2);
		lc.add(c3);
		c2.setId(1);
		System.out.println(c2.getName());
		//addProduct("Style", 44, lc);
		//addProduct("Cahier", 22, lc);
		/*addProduct("Voiture", 2202);*/
		//supprimerProduct(1);
		//updateProduct("pomme", 700, 2);
		//listProducts();
		// Cleaning up connection pool
		factory.close();
	}
	
	public static void addProduct(String name, int price, List<Category> lc)
	{
		Session session = factory.openSession();
		Transaction transaction = null;
		try {
			transaction = session.beginTransaction();
			// insert new product
			Product product = new Product();
			product.setName(name);
			product.setPrice(price);
			product.setCategories(lc);
			System.out.println("Infos product :"+product.getId()+"-" +
			product.getName() + "-"+product.getPrice());
			int inserted_id = (Integer) session.save(product);
			System.err.println("Inserted ID : " + inserted_id);
			transaction.commit();
		}
		catch (Exception e) {
			if (transaction != null)
			{
				transaction.rollback();
			}
			System.out.println("ERROR: " + e.getMessage());
		} 
		finally
		{
			session.close();
		}
	}
	
	
	public static void addCategory(String name)
	{
		Session session = factory.openSession();
		Transaction transaction = null;
		try {
			transaction = session.beginTransaction();
			// insert new product
			Category category = new Category();
			category.setName(name);
			System.out.println("Infos product :"+category.getId()+"-" +
			category.getName() + "-"+category.getId());
			int inserted_id = (Integer) session.save(category);
			System.err.println("Inserted ID : " + inserted_id);
			transaction.commit();
		}
		catch (Exception e) {
			if (transaction != null)
			{
				transaction.rollback();
			}
			System.out.println("ERROR: " + e.getMessage());
		} 
		finally
		{
			session.close();
		}
	}
	
	public static void updateProduct(String name, int price, int id)
	{
		Session session = factory.openSession();
		Transaction transaction = null;
		try {
			transaction = session.beginTransaction();
			// insert new product
			Product product = new Product();
			product.setId(id);
			product.setName(name);
			product.setPrice(price);
			System.out.println("Infos product :"+product.getId()+"-" +
			product.getName() + "-"+product.getPrice());
			//int inserted_id = (Integer) session.save(product);
			session.update(product);
			//System.err.println("Inserted ID : " + inserted_id);
			transaction.commit();
		}
		catch (Exception e) {
			if (transaction != null)
			{
				transaction.rollback();
			}
			System.out.println("ERROR: " + e.getMessage());
		} 
		finally
		{
			session.close();
		}
	}
	
	
	public static void updateCategory(String name, int id)
	{
		Session session = factory.openSession();
		Transaction transaction = null;
		try {
			transaction = session.beginTransaction();
			// insert new product
			Category category = new Category();
			category.setId(id);
			category.setName(name);
			System.out.println("Infos product :"+category.getId()+"-" +
			category.getName());
			//int inserted_id = (Integer) session.save(product);
			session.update(category);
			//System.err.println("Inserted ID : " + inserted_id);
			transaction.commit();
		}
		catch (Exception e) {
			if (transaction != null)
			{
				transaction.rollback();
			}
			System.out.println("ERROR: " + e.getMessage());
		} 
		finally
		{
			session.close();
		}
	}
	
	
	public static void listProducts()
	{
		Session session = factory.openSession();
		Transaction transaction = null;
	try
	{
		transaction = session.beginTransaction();
		// Get products by executing HQL Query
		List products = session.createQuery("FROM Product").list();
		for (Iterator iterator = products.iterator(); iterator.hasNext();)
		{
			Product product = (Product) iterator.next();
			System.out.print("ID: " + product.getId());
			System.out.print(" ===> NAME: " + product.getName());
			System.out.println(" ===> PRICE: " + product.getPrice());
			for(int i = 0; i < product.getCategories().size(); i++) {
				System.out.println(product.getCategories().get(i).getName() + " ID: " + product.getCategories().get(i).getId());
			}
			}
			transaction.commit();
	} 
	catch (Exception e)
	{
			if (transaction != null)
			{
				transaction.rollback();
			}
			System.out.println("ERROR: " + e.getMessage());
	} 
	finally
	{
		session.close();
	}
	}
	
	
	
	public static void supprimerProduct(int id)
	{
		Session session = factory.openSession();
		Transaction transaction = null;
		try {
			transaction = session.beginTransaction();
			// insert new product
			Product product = new Product();
			product.setId(id);
			System.out.println("Infos product :"+product.getId()+"-");
			
			for(int i = 0; i < product.getCategories().size(); i++) {
				//System.out.println(product.getCategories().get(i).getName() + " ID: " + product.getCategories().get(i).getId());
				session.delete(product.getCategories().get(i));
			}
			
			session.delete(product);
			transaction.commit();
		}
		catch (Exception e) {
			if (transaction != null)
			{
				transaction.rollback();
			}
			System.out.println("ERROR: " + e.getMessage());
		} 
		finally
		{
			session.close();
		}
	}
	
	
	public static void supprimerCategory(int id)
	{
		Session session = factory.openSession();
		Transaction transaction = null;
		try {
			transaction = session.beginTransaction();
			// insert new product
			Category category = new Category();
			category.setId(id);
			System.out.println("Infos product :"+category.getId()+"-");
			session.delete(category);
			transaction.commit();
		}
		catch (Exception e) {
			if (transaction != null)
			{
				transaction.rollback();
			}
			System.out.println("ERROR: " + e.getMessage());
		} 
		finally
		{
			session.close();
		}
	}
}