package net.isetjb.tp4;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "category")
public class Category {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id", nullable = false)
	private int id;
	@Column(name = "name", length = 255, nullable = true)
	private String name;
	// uncomment this to have bidirectionnel mode
	// Bidirectionnel "Many To Many" :
	// @ManyToMany(fetch = FetchType.LAZY, mappedBy = "categories")
	// private List<Product> products = new ArrayList<>();
	// public List<Product> getProducts() {
	// return products;
	// }
	//
	// public void setProducts(List<Product> products) {
	// this.products = products;
	// }
	
	// Getters and Setters here...
	public Category(int id, String name) {
		super();
		this.id = id;
		this.name = name;
	}
	public Category() {
		
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	
	
}