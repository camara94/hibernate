package net.isetjb.hibernatetutorial3;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.envers.Audited;
public class Application
{
	private static SessionFactory factory;
	public static void main(String[] args)
	{
		// Open connection pool
		factory = HibernateUtil.getSessionFactory();
		// CRUD calls examples
		addProduct("Style", 44);
		addProduct("Cahier", 22);
		addProduct("Voiture", 2202);
		//supprimerProduct(1);
		//updateProduct("pomme", 700, 2);
		listProducts();
		// Cleaning up connection pool
		factory.close();
	}
	
	public static void addProduct(String name, int price)
	{
		Session session = factory.openSession();
		Transaction transaction = null;
		try {
			transaction = session.beginTransaction();
			// insert new product
			Product product = new Product();
			product.setName(name);
			product.setPrice(price);
			System.out.println("Infos product :"+product.getId()+"-" +
			product.getName() + "-"+product.getPrice());
			int inserted_id = (Integer) session.save(product);
			System.err.println("Inserted ID : " + inserted_id);
			transaction.commit();
		}
		catch (Exception e) {
			if (transaction != null)
			{
				transaction.rollback();
			}
			System.out.println("ERROR: " + e.getMessage());
		} 
		finally
		{
			session.close();
		}
	}
	
	public static void updateProduct(String name, int price, int id)
	{
		Session session = factory.openSession();
		Transaction transaction = null;
		try {
			transaction = session.beginTransaction();
			// insert new product
			Product product = new Product();
			product.setId(id);
			product.setName(name);
			product.setPrice(price);
			System.out.println("Infos product :"+product.getId()+"-" +
			product.getName() + "-"+product.getPrice());
			//int inserted_id = (Integer) session.save(product);
			session.update(product);
			//System.err.println("Inserted ID : " + inserted_id);
			transaction.commit();
		}
		catch (Exception e) {
			if (transaction != null)
			{
				transaction.rollback();
			}
			System.out.println("ERROR: " + e.getMessage());
		} 
		finally
		{
			session.close();
		}
	}
	
	
	public static void listProducts()
	{
		Session session = factory.openSession();
		Transaction transaction = null;
	try
	{
		transaction = session.beginTransaction();
		// Get products by executing HQL Query
		List products = session.createQuery("FROM Product").list();
		for (Iterator iterator = products.iterator(); iterator.hasNext();)
		{
			Product product = (Product) iterator.next();
			System.out.print("ID: " + product.getId());
			System.out.print(" ===> NAME: " + product.getName());
			System.out.println(" ===> PRICE: " + product.getPrice());
			}
			transaction.commit();
	} 
	catch (Exception e)
	{
			if (transaction != null)
			{
				transaction.rollback();
			}
			System.out.println("ERROR: " + e.getMessage());
	} 
	finally
	{
		session.close();
	}
	}
	
	
	
	public static void supprimerProduct(int id)
	{
		Session session = factory.openSession();
		Transaction transaction = null;
		try {
			transaction = session.beginTransaction();
			// insert new product
			Product product = new Product();
			product.setId(id);
			System.out.println("Infos product :"+product.getId()+"-");
			session.delete(product);
			transaction.commit();
		}
		catch (Exception e) {
			if (transaction != null)
			{
				transaction.rollback();
			}
			System.out.println("ERROR: " + e.getMessage());
		} 
		finally
		{
			session.close();
		}
	}
}