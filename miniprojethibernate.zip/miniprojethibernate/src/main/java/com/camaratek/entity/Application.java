package com.camaratek.entity;



import java.util.Iterator;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;


import com.camaratek.fenetre.Fenetre;



public class Application
{
	static SessionFactory factory;
	@SuppressWarnings("unused")
	public static void main(String[] args)
	{
		// Open connection pool
		factory = HibernateUtil.getSessionFactory();
		// CRUD calls examples
		/*Famille fam = new Famille("Formiture", "Ce sont de fournitures scolaires");
		
		Etiquette et = new Etiquette();
		et.setCouleur("Jaune");
		et.setNom("Mon etiquette N� 1");
		
		Produit p = new Produit("camara","Laby Damaro", 5689);
		Famille f = new Famille();
		addFamille(f);
		f.setId(1);
		p.setFamille(f);
		et.setId(1);
		p.setEtiquettees(et);
		
		addProduit(p);*/
		
		
		//addFamille(fam);
		//supprimerFamille(3);
		//listFamilles();
		/*fam.setId(1);/*
		Produit p = new Produit();
		p.setDescription("Produit cosmetiques");
		//p.setEtiquettees();
		p.setFamille(fam);
		p.setPriceUnitaire(20);
		p.setReference("Nivea creme soft");
		//addProduit(p);
		//updateProduit(1, p);
		listProduits();
		Produit p = new Produit();
		p.setId(6);
		Etiquette et = new Etiquette();
		et.setCouleur("Jaune");
		et.setNom("Mon etiquette N� 1");
		et.setProduits(p);
		
		/*addEtiquette(et);
		listEtiquettes();*/
		
		// Cleaning up connection pool
		//FamilleDAO.
		
		/*Client clt = new Client("Camara","Foyer Universitaire");
		addClient(clt);
		clt.setNom("Laby Damaro");
		updateClient(1, clt);
		listClients();*/
		
		/*Client client = new Client();
		client.setId(1);
		
		Produit prod = new Produit();
		prod.setId(3);
		
		Commande cmd = new Commande();
		cmd.setClient(client);
		List l =new ArrayList<Produit>();
				l.add(prod);
				l.add(prod);
		cmd.setProduits(l);
		addCommande(cmd);
		
		//listCommandes();
		//updateCommande(1, cmd);
		//listClients();
		listCommandes();*/
		//listClients();
		//listCommandes();
		//listEtiquettes();
		//listFamilles();
		//listProduits();
		
		//Fenetre f = new Fenetre(new Application(), listClients(), listProduits(), listCommandes());
		Fenetre f = new Fenetre(new Application(), listFamilles(), listEtiquettes(), listClients(), listProduits(), listCommandes());
		//supprimerProduit(3);
		listFamilles();
		//listCommandes();
		
		//supprimerProduit(2);
		//supprimerCommande(2);
		//supprimerProduit(3);		
		//factory.close();
		
		
		/*Client clt = listClients().get(1);
		List<Produit> lp = new ArrayList<Produit>();
		Produit pp = listProduits().get(2);
		
		
		lp.add(pp);
		
		Produit prod = new Produit();
		Commande cmd = new Commande();
		cmd.setClient(clt);
		cmd.setProduit(pp);
		//cmd.setProduit(prod);
		addCommande(cmd);
		listCommandes();
		//System.out.println(p.getDescription());*/
		
		
		/*Produit p = new Produit();
		p.setDescription("Produit cosmetiques");
		Famille fam = new Famille("Formiture", "Ce sont de fournitures scolaires");
		addFamille(fam);
		fam.setId(1);
		Etiquette et = new Etiquette();
		et.setCouleur("Jaune");
		et.setNom("Mon etiquette N� 1");
		//p.setEtiquettees();
		p.setFamille(fam);
		p.setPriceUnitaire(20);
		p.setReference("Nivea creme soft");
		;
		
		et.setCouleur("Jaune");
		et.setNom("Mon etiquette N� 1");
		
		addProduit(p);
		//updateProduit(1, p)*/
		
		/*Famille f = new Famille();
		Client c = new Client();
		c.setId(2);
		f.setNom("Formiture");
		Produit pp = new Produit("T�l�phone","Samsung s5", 125, f);
		
		addProduit(pp);*/
		//System.out.println(c.getNom());
		
		
	}
	
	// CRUD DE Famille
	
	public static void addFamille(Famille fam)
	{
		factory = HibernateUtil.getSessionFactory();
		Session session = factory.openSession();
		Transaction transaction = null;
		try {
			transaction = session.beginTransaction();
			// insert new product
			Famille famille = new Famille();
			famille.setId(fam.getId());
			famille.setNom(fam.getNom());
			famille.setDescription(fam.getDescription());
			System.out.println("Infos Famille :"+famille.getId()+"-" +
					famille.getNom() + "-"+famille.getDescription());
			int inserted_id = (Integer) session.save(famille);
			System.err.println("Inserted ID : " + inserted_id);
			transaction.commit();
		}
		catch (Exception e) {
			if (transaction != null)
			{
				transaction.rollback();
			}
			System.out.println("ERROR: " + e.getMessage());
		} 
		finally
		{
			session.close();
		}
	}
	
	
	
	@SuppressWarnings("unchecked")
	public static List<Famille> listFamilles()
	{
		Session session = factory.openSession();
		Transaction transaction = null;
		List<Famille> familles = null;
		try
		{
			transaction = session.beginTransaction();
			// Get products by executing HQL Query
			familles = session.createQuery("FROM Famille").list();
			for (Iterator<?> iterator = familles.iterator(); iterator.hasNext();)
			{
				Famille famille = (Famille) iterator.next();
				System.out.print("ID: " + famille.getId());
				System.out.print(" ===> NAME: " + famille.getNom());
				System.out.println(" ===> DESCRIPTION: " + famille.getDescription());
				
			}
			transaction.commit();
		} 
		catch (Exception e)
		{
				if (transaction != null)
				{
					transaction.rollback();
				}
				System.out.println("ERROR: " + e.getMessage());
		} 
		finally
		{
			session.close();
		}
		return familles;
	}
	
	
	
	@SuppressWarnings("unchecked")
	public static Famille getFamille(int id)
	{
		Famille famille = null;
		Session session = factory.openSession();
		Transaction transaction = null;
		List<Famille> familles = null;
		try
		{
			transaction = session.beginTransaction();
			// Get products by executing HQL Query
			familles = session.createQuery("FROM Famille").list();
			for (int i = 0; i < familles.size(); i++)
			{
				if (familles.get(i).getId() == id)
				{
					famille = familles.get(i);
				}
			}
			transaction.commit();
		} 
		catch (Exception e)
		{
				if (transaction != null)
				{
					transaction.rollback();
				}
				System.out.println("ERROR: " + e.getMessage());
		} 
		finally
		{
			session.close();
		}
		return famille;
	}
	
	
	
	
	
	
	public static void updateFamille(int id, Famille fam)
	{
		Session session = factory.openSession();
		Transaction transaction = null;
		try {
			transaction = session.beginTransaction();
			// insert new product
			Famille famille = new Famille();
			famille.setId(id);
			famille.setNom(fam.getNom());
			famille.setDescription(fam.getDescription());
			System.out.println("UPDATED Famille :"+famille.getId()+"-" +
					famille.getNom() + "-"+famille.getDescription());
			//int inserted_id = (Integer) session.save(product);
			session.update(famille);
			//System.err.println("Inserted ID : " + inserted_id);
			transaction.commit();
		}
		catch (Exception e) {
			if (transaction != null)
			{
				transaction.rollback();
			}
			System.out.println("ERROR: " + e.getMessage());
		} 
		finally
		{
			session.close();
		}
	}
	
	public static void supprimerFamille(int id)
	{
		Session session = factory.openSession();
		Transaction transaction = null;
		try {
			transaction = session.beginTransaction();
			// insert new product
			Famille famille = new Famille();
			famille.setId(id);
			System.out.println("Vous avez supprimer :" + famille.getId()+"-");
			@SuppressWarnings("unchecked")
			List<Produit> produits = session.createQuery("FROM Produit").list();
			for(int i = 0; i < produits.size(); i++) {
				//System.out.println(product.getCategories().get(i).getName() + " ID: " + product.getCategories().get(i).getId());
				if(famille.getId() == produits.get(i).getFamille().getId()) {
					session.delete(produits.get(i));
				}
			}
			
			session.delete(famille);
			transaction.commit();
		}
		catch (Exception e) {
			if (transaction != null)
			{
				transaction.rollback();
			}
			System.out.println("ERROR: " + e.getMessage());
		} 
		finally
		{
			session.close();
		}
	}
	
	
	
	
	
	
	// CRUD DE Produit
	
		public static void addProduit(Produit prod)
		{
			factory = HibernateUtil.getSessionFactory();
			Session session = factory.openSession();
			Transaction transaction = null;
			try {
				transaction = session.beginTransaction();
				// insert new product
				Produit produit = new Produit();
				produit.setId(prod.getId());
				produit.setReference(prod.getReference());
				produit.setDescription(prod.getDescription());
				produit.setPriceUnitaire(prod.getPriceUnitaire());
				produit.setEtiquettes(prod.getEtiquettes());
				produit.setFamille(prod.getFamille());
				System.out.println("Infos Produit :"+produit.getId()+"-" +
						produit.getReference() + "-"+produit.getDescription());
				int inserted_id = (Integer) session.save(produit);
				System.err.println("Inserted ID : " + inserted_id);
				transaction.commit();
			}
			catch (Exception e) {
				if (transaction != null)
				{
					transaction.rollback();
				}
				System.out.println("ERROR: " + e.getMessage());
			} 
			finally
			{
				session.close();
			}
		}
		
		
		
		@SuppressWarnings("unchecked")
		public static List<Produit> listProduits()
		{
			Session session = factory.openSession();
			Transaction transaction = null;
			List<Produit> produits = null;
			try
			{
				transaction = session.beginTransaction();
				// Get products by executing HQL Query
				produits = session.createQuery("FROM Produit").list();
				for (Iterator<?> iterator = produits.iterator(); iterator.hasNext();)
				{
					Produit produit = (Produit) iterator.next();
					System.out.print("ID: " + produit.getId());
					System.out.print(" ===> REFERENCE: " + produit.getReference());
					System.out.println(" ===> DESCRIPTION: " + produit.getDescription());
					System.out.println(" ===> taille: " + produit.getEtiquettes().get(0).getNom());
					
				}
				transaction.commit();
			} 
			catch (Exception e)
			{
					if (transaction != null)
					{
						transaction.rollback();
					}
					System.out.println("ERROR: " + e.getMessage());
			} 
			finally
			{
				session.close();
			}
			return produits;
		}
		
		
		@SuppressWarnings("unchecked")
		public static Produit getProduit(int id)
		{
			Produit produit = null;
			Session session = factory.openSession();
			Transaction transaction = null;
			List<Produit> produits = null;
			try
			{
				transaction = session.beginTransaction();
				// Get products by executing HQL Query
				produits = session.createQuery("FROM Produit").list();
				for (int i = 0; i < produits.size(); i++)
				{
					if (produits.get(i).getId() == id)
					{
						produit = produits.get(i);
					}
				}
				transaction.commit();
			} 
			catch (Exception e)
			{
					if (transaction != null)
					{
						transaction.rollback();
					}
					System.out.println("ERROR: " + e.getMessage());
			} 
			finally
			{
				session.close();
			}
			return produit;
		}
		
		
		public static void updateProduit(int id, Produit prod)
		{
			Session session = factory.openSession();
			Transaction transaction = null;
			try {
				transaction = session.beginTransaction();
				// insert new product
				Produit produit = new Produit();
				produit.setId(id);
				produit.setReference(prod.getReference());
				produit.setDescription(prod.getDescription());
				produit.setPriceUnitaire(prod.getPriceUnitaire());
				produit.setEtiquettes(prod.getEtiquettes());
				produit.setFamille(prod.getFamille());
				System.out.println("Infos Produit :"+produit.getId()+"-" +
						produit.getReference() + "-"+produit.getDescription());
				session.update(produit);
				
				transaction.commit();
			}
			catch (Exception e) {
				if (transaction != null)
				{
					transaction.rollback();
				}
				System.out.println("ERROR: " + e.getMessage());
			} 
			finally
			{
				session.close();
			}
		}
		
		
		
		public static void supprimerProduit(int id)
		{
			Session session = factory.openSession();
			Transaction transaction = null;
			try {
				transaction = session.beginTransaction();
				// insert new product
				Produit produit = new Produit();
				produit.setId(id);
				System.out.println("Infos product :"+produit.getId()+"-");
				
				for(int i = 0; i < produit.getEtiquettes().size(); i++) {
					//System.out.println(product.getCategories().get(i).getName() + " ID: " + product.getCategories().get(i).getId());
					session.delete(produit.getEtiquettes().get(i));
				}
				
				session.delete(produit);
				transaction.commit();
			}
			catch (Exception e) {
				if (transaction != null)
				{
					transaction.rollback();
				}
				System.out.println("ERROR: " + e.getMessage());
			} 
			finally
			{
				session.close();
			}
		}
		
		
		
		
		// CRUD DE Etiquette
		
			public static void addEtiquette(Etiquette et)
			{
				factory = HibernateUtil.getSessionFactory();
				Session session = factory.openSession();
				Transaction transaction = null;
				try {
					transaction = session.beginTransaction();
					// insert new product
					Etiquette etiquette = new Etiquette();
					etiquette.setCouleur(et.getCouleur());
					etiquette.setNom(et.getNom());
					System.out.println("Infos Produit :"+etiquette.getId()+"-" +
							etiquette.getCouleur() + "-"+etiquette.getNom());
					int inserted_id = (Integer) session.save(etiquette);
					System.err.println("Inserted ID : " + inserted_id);
					transaction.commit();
				}
				catch (Exception e) {
					if (transaction != null)
					{
						transaction.rollback();
					}
					System.out.println("ERROR: " + e.getMessage());
				} 
				finally
				{
					session.close();
				}
			}
			
			
			
			@SuppressWarnings("unchecked")
			public static List<Etiquette> listEtiquettes()
			{
				Session session = factory.openSession();
				Transaction transaction = null;
				List<Etiquette> etiquettes = null;
				try
				{
					transaction = session.beginTransaction();
					// Get products by executing HQL Query
					etiquettes = session.createQuery("FROM Etiquette").list();
					for (Iterator<?> iterator = etiquettes.iterator(); iterator.hasNext();)
					{
						Etiquette etiquette = (Etiquette) iterator.next();
						System.out.print("ID: " + etiquette.getId());
						System.out.print(" ===> NOM: " + etiquette.getNom());
						System.out.println(" ===> COULEUR: " + etiquette.getCouleur());
						
					}
					transaction.commit();
				} 
				catch (Exception e)
				{
						if (transaction != null)
						{
							transaction.rollback();
						}
						System.out.println("ERROR: " + e.getMessage());
				} 
				finally
				{
					session.close();
				}
				return etiquettes;
			}
			
			
			
			
			@SuppressWarnings("unchecked")
			public static Etiquette getEtiquette(int id)
			{
				Etiquette etiquette = null;
				Session session = factory.openSession();
				Transaction transaction = null;
				List<Etiquette> etiquettes = null;
				try
				{
					transaction = session.beginTransaction();
					// Get products by executing HQL Query
					etiquettes = session.createQuery("FROM Etiquette").list();
					for (int i = 0; i < etiquettes.size(); i++)
					{
						if (etiquettes.get(i).getId() == id)
						{
							etiquette = etiquettes.get(i);
						}
					}
					transaction.commit();
				} 
				catch (Exception e)
				{
						if (transaction != null)
						{
							transaction.rollback();
						}
						System.out.println("ERROR: " + e.getMessage());
				} 
				finally
				{
					session.close();
				}
				return etiquette;
			}
			
			
			
			public static void updateEtiquette(int id, Etiquette et)
			{
				Session session = factory.openSession();
				Transaction transaction = null;
				try {
					transaction = session.beginTransaction();
					// insert new product
					Etiquette etiquette = new Etiquette();
					etiquette.setId(id);
					etiquette.setCouleur(et.getCouleur());
					etiquette.setNom(et.getNom());
					System.out.println("Infos Produit :"+etiquette.getId()+"-" +
							etiquette.getCouleur() + "-"+etiquette.getNom());
					session.update(etiquette);
					
					transaction.commit();
				}
				catch (Exception e) {
					if (transaction != null)
					{
						transaction.rollback();
					}
					System.out.println("ERROR: " + e.getMessage());
				} 
				finally
				{
					session.close();
				}
			}
			
			
			
			public static void supprimerEtiquette(int id)
			{
				Session session = factory.openSession();
				Transaction transaction = null;
				try {
					transaction = session.beginTransaction();
					// insert new product
					Etiquette etiquette = new Etiquette();
					etiquette.setId(id);
					System.out.println("Vous avez supprimer :" + etiquette.getId()+"-");
					@SuppressWarnings("unchecked")
					List<Produit> produits = session.createQuery("FROM Produit").list();
					for(int i = 0; i < produits.size(); i++) {
						//System.out.println(product.getCategories().get(i).getName() + " ID: " + product.getCategories().get(i).getId());
						if(produits.get(i).getEtiquettes().size() > 0) {
							for (Etiquette e: produits.get(i).getEtiquettes())
							{
								if (etiquette.getId() == e.getId())
								{
									session.delete(e);
								}
									
							}
							
						}
					}
					
					session.delete(etiquette);
					transaction.commit();
				}
				catch (Exception e) {
					if (transaction != null)
					{
						transaction.rollback();
					}
					System.out.println("ERROR: " + e.getMessage());
				} 
				finally
				{
					session.close();
				}
			}
			
			
			
			
			
			
			
			
			// CRUD DE Commande
			
			public static void addCommande(Commande cmd)
			{
				factory = HibernateUtil.getSessionFactory();
				Session session = factory.openSession();
				Transaction transaction = null;
				try {
					transaction = session.beginTransaction();
					// insert new product
					Commande commande = new Commande();
					commande.setId(cmd.getId());
					commande.setClient(cmd.getClient());
					commande.setProduits(cmd.getProduits());
					commande.setDateCommande(cmd.getDateCommande());
					
					System.out.println("Infos Commande :"+ commande.getId()+"-" +
							commande.getDateCommande() + "-" + commande.getClient().getNom());
					int inserted_id = (Integer) session.save(commande);
					System.err.println("Inserted ID : " + inserted_id);
					transaction.commit();
				}
				catch (Exception e) {
					if (transaction != null)
					{
						transaction.rollback();
					}
					System.out.println("ERROR: " + e.getMessage());
				} 
				finally
				{
					session.close();
				}
			}
			
			
			
			@SuppressWarnings("unchecked")
			public static List<Commande> listCommandes()
			{
				Session session = factory.openSession();
				Transaction transaction = null;
				List<Commande> commandes = null;
				try
				{
					transaction = session.beginTransaction();
					// Get products by executing HQL Query
					commandes = session.createQuery("FROM Commande").list();
					for (Iterator<?> iterator = commandes.iterator(); iterator.hasNext();)
					{
						Commande commande = (Commande) iterator.next();
						System.out.print("ID: " + commande.getId());
						System.out.print(" ===> CLIENT NAME: " + commande.getClient().getNom());
						//System.out.println(" ===> NUMBERS OF PRODUCT :  " + commande.getProduits().get(0).getReference());
						for(int i = 0; i < commande.getProduits().size(); i++) {
							System.out.println(commande.getProduits().get(i).getDescription() );
						}
						
					}
					transaction.commit();
				} 
				catch (Exception e)
				{
						if (transaction != null)
						{
							transaction.rollback();
						}
						System.out.println("ERROR: " + e.getMessage());
				} 
				finally
				{
					session.close();
				}
				return commandes;
			}
			
			
			public static void updateCommande(int id, Commande cmd)
			{
				Session session = factory.openSession();
				Transaction transaction = null;
				try {
					transaction = session.beginTransaction();
					// insert new product
					Commande commande = new Commande();
					commande.setId(id);
					commande.setClient(cmd.getClient());
					commande.setProduits(cmd.getProduits());
					commande.setDateCommande(cmd.getDateCommande());
					/*System.out.println("Infos Commande :"+ commande.getId()+"-" +
							commande.getDateCommande() + "-" + commande.getClient().getNom());*/
					session.update(commande);
					
					transaction.commit();
				}
				catch (Exception e) {
					if (transaction != null)
					{
						transaction.rollback();
					}
					System.out.println("ERROR: " + e.getMessage());
				} 
				finally
				{
					session.close();
				}
			}
			
			
			
			public static void supprimerCommande(int id)
			{
				Session session = factory.openSession();
				Transaction transaction = null;
				try {
					transaction = session.beginTransaction();
					// insert new product
					Commande commande = new Commande();
					commande.setId(id);
					System.out.println("Vous avez supprimer :" + commande.getId()+"-");
					/*for(int i = 0; i < produit.getEtiquettes().size(); i++) {
						//System.out.println(product.getCategories().get(i).getName() + " ID: " + product.getCategories().get(i).getId());
						session.delete(produit.getEtiquettes().get(i));
					}*/
					session.delete(commande);
					transaction.commit();
				}
				catch (Exception e) {
					if (transaction != null)
					{
						transaction.rollback();
					}
					System.out.println("ERROR: " + e.getMessage());
				} 
				finally
				{
					session.close();
				}
			}
			
			
			
			
			// CRUD DE Client
			
			public static void addClient(Client clt)
			{
				factory = HibernateUtil.getSessionFactory();
				Session session = factory.openSession();
				Transaction transaction = null;
				try {
					transaction = session.beginTransaction();
					// insert new product
					Client client = new Client();
					client.setId(clt.getId());
					client.setNom(clt.getNom());
					client.setAdresse(clt.getAdresse());
					System.out.println("Infos Famille :"+ client.getId()+"-" +
							client.getNom() + "-"+client.getAdresse());
					int inserted_id = (Integer) session.save(client);
					System.err.println("Inserted ID : " + inserted_id);
					transaction.commit();
				}
				catch (Exception e) {
					if (transaction != null)
					{
						transaction.rollback();
					}
					System.out.println("ERROR: " + e.getMessage());
				} 
				finally
				{
					session.close();
				}
			}
			
			
			
			@SuppressWarnings("unchecked")
			public static List<Client> listClients()
			{
				Session session = factory.openSession();
				Transaction transaction = null;
				List<Client> clients = null;
				try
				{
					transaction = session.beginTransaction();
					// Get products by executing HQL Query
					clients = session.createQuery("FROM Client").list();
					/*for (Iterator iterator = clients.iterator(); iterator.hasNext();)
					{
						Client client = (Client) iterator.next();
						System.out.print("ID: " + client.getId());
						System.out.print(" ===> NAME: " + client.getNom());
						System.out.println(" ===> DESCRIPTION: " + client.getAdresse());
						
					}*/
					
					transaction.commit();
					
				} 
				catch (Exception e)
				{
						if (transaction != null)
						{
							transaction.rollback();
						}
						System.out.println("ERROR: " + e.getMessage());
				} 
				finally
				{
					
					session.close();
				}
				return clients;
			}
			
			
			@SuppressWarnings("unchecked")
			public static Client getClient(int id)
			{
				Client client = null;
				Session session = factory.openSession();
				Transaction transaction = null;
				List<Client> clients = null;
				try
				{
					transaction = session.beginTransaction();
					// Get products by executing HQL Query
					clients = session.createQuery("FROM Client").list();
					for (int i = 0; i < clients.size(); i++)
					{
						if (clients.get(i).getId() == id)
						{
							client = clients.get(i);
						}
					}
					transaction.commit();
				} 
				catch (Exception e)
				{
						if (transaction != null)
						{
							transaction.rollback();
						}
						System.out.println("ERROR: " + e.getMessage());
				} 
				finally
				{
					session.close();
				}
				return client;
			}
			
			
			public static void updateClient(int id, Client clt)
			{
				Session session = factory.openSession();
				Transaction transaction = null;
				try {
					transaction = session.beginTransaction();
					// insert new product
					Client client = new Client();
					client.setId(id);
					client.setNom(clt.getNom());
					client.setAdresse(clt.getAdresse());
					System.out.println("Infos Famille :"+ client.getId()+"-" +
							client.getNom() + "-"+client.getAdresse());
					session.update(client);
					transaction.commit();
				}
				catch (Exception e) {
					if (transaction != null)
					{
						transaction.rollback();
					}
					System.out.println("ERROR: " + e.getMessage());
				} 
				finally
				{
					session.close();
				}
			}
			
			public static void supprimerClient(int id)
			{
				Session session = factory.openSession();
				Transaction transaction = null;
				try {
					transaction = session.beginTransaction();
					// insert new product
					Client client = new Client();
					client.setId(id);
					System.out.println("Vous avez supprimer :" + client.getId()+"-");
					@SuppressWarnings({ "unchecked", "unused" })
					List<Commande> commandes = session.createQuery("FROM Commande").list();
					session.delete(client);
					transaction.commit();
				}
				catch (Exception e) {
					if (transaction != null)
					{
						transaction.rollback();
					}
					System.out.println("ERROR: " + e.getMessage());
				} 
				finally
				{
					session.close();
				}
			}
			
			
			
			
			
	

}
