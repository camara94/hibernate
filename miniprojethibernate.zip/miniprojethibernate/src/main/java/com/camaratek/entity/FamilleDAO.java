package com.camaratek.entity;

import java.util.Iterator;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.camaratek.entity.Famille;
import com.camaratek.entity.Produit;

public class FamilleDAO {
	
	 static SessionFactory factory;
	
	public FamilleDAO() {
		// TODO Auto-generated constructor stub
		
	}
	
	
	public void addFamille(Famille fam)
	{
		
		Session session = factory.openSession();
		Transaction transaction = null;
		try {
			transaction = session.beginTransaction();
			// insert new product
			Famille famille = new Famille();
			famille.setId(fam.getId());
			famille.setNom(fam.getNom());
			famille.setDescription(fam.getDescription());
			System.out.println("Infos Famille :"+famille.getId()+"-" +
					famille.getNom() + "-"+famille.getDescription());
			int inserted_id = (Integer) session.save(famille);
			System.err.println("Inserted ID : " + inserted_id);
			transaction.commit();
		}
		catch (Exception e) {
			if (transaction != null)
			{
				transaction.rollback();
			}
			System.out.println("ERROR: " + e.getMessage());
		} 
		finally
		{
			session.close();
		}
	}
	
	
	
	public static void listFamilles()
	{
		Session session = factory.openSession();
		Transaction transaction = null;
		try
		{
			transaction = session.beginTransaction();
			// Get products by executing HQL Query
			@SuppressWarnings("unchecked")
			List<Famille> familles = session.createQuery("FROM Famille").list();
			for (Iterator<?> iterator = familles.iterator(); iterator.hasNext();)
			{
				Famille famille = (Famille) iterator.next();
				System.out.print("ID: " + famille.getId());
				System.out.print(" ===> NAME: " + famille.getNom());
				System.out.println(" ===> DESCRIPTION: " + famille.getDescription());
				
			}
			transaction.commit();
		} 
		catch (Exception e)
		{
				if (transaction != null)
				{
					transaction.rollback();
				}
				System.out.println("ERROR: " + e.getMessage());
		} 
		finally
		{
			session.close();
		}
	}
	
	
	
	
	public static void updateFamille(int id, Famille fam)
	{
		Session session = factory.openSession();
		Transaction transaction = null;
		try {
			transaction = session.beginTransaction();
			// insert new product
			Famille famille = new Famille();
			famille.setId(id);
			famille.setNom(fam.getNom());
			famille.setDescription(fam.getDescription());
			System.out.println("UPDATED Famille :"+famille.getId()+"-" +
					famille.getNom() + "-"+famille.getDescription());
			//int inserted_id = (Integer) session.save(product);
			session.update(famille);
			//System.err.println("Inserted ID : " + inserted_id);
			transaction.commit();
		}
		catch (Exception e) {
			if (transaction != null)
			{
				transaction.rollback();
			}
			System.out.println("ERROR: " + e.getMessage());
		} 
		finally
		{
			session.close();
		}
	}
	
	
	
	
	public static void supprimerFamille(int id)
	{
		Session session = factory.openSession();
		Transaction transaction = null;
		try {
			transaction = session.beginTransaction();
			// insert new product
			Famille famille = new Famille();
			famille.setId(id);
			System.out.println("Infos product :" + famille.getId()+"-");
			@SuppressWarnings("unchecked")
			List<Produit> produits = session.createQuery("FROM Produit").list();
			for(int i = 0; i < produits.size(); i++) {
				//System.out.println(product.getCategories().get(i).getName() + " ID: " + product.getCategories().get(i).getId());
				if(famille.getId() == produits.get(i).getFamille().getId()) {
					session.delete(produits.get(i));
				}
			}
			
			session.delete(famille);
			transaction.commit();
		}
		catch (Exception e) {
			if (transaction != null)
			{
				transaction.rollback();
			}
			System.out.println("ERROR: " + e.getMessage());
		} 
		finally
		{
			session.close();
		}
	}
	
}
