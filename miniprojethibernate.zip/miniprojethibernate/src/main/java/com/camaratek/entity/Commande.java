package com.camaratek.entity;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.ForeignKey;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.Table;


@Entity
@Table(name = "commande")
public class Commande implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id", nullable = false)
	private int id;
	@Column(name = "dateCommande", nullable = false)
	private Date dateCommande;
	@ManyToMany(cascade = CascadeType.ALL)
	@JoinTable(name = "commande_produit",
		joinColumns = {
				@JoinColumn(name = "commande_id")
				},
		inverseJoinColumns = {
				@JoinColumn(name = "produit_id")
				}
	)
	private List<Produit> produits = new ArrayList<Produit>();
	
	@ManyToOne
	@JoinColumn(name = "client_id",  foreignKey = @ForeignKey(name = "CLIENT_ID_FK"))
	private Client client;

	public Commande() {
		// TODO Auto-generated constructor stub
		this.dateCommande = new Date();
	}

	public Commande(Client client, List<Produit> produits) {
		super();
		this.dateCommande = new Date();
		this.produits = produits;
		this.client = client;
	}
	
	public Commande(Date dateCommande, Produit produit) {
		super();
		this.dateCommande = dateCommande;
		this.produits.add(produit);
	}
	
	

	public Commande(Date dateCommande, List<Produit> produits, Client client) {
		super();
		this.dateCommande = dateCommande;
		this.produits = produits;
		this.client = client;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Date getDateCommande() {
		return dateCommande;
	}

	public void setDateCommande(Date dateCommande) {
		this.dateCommande = dateCommande;
	}

	public List<Produit> getProduits() {
		return this.produits;
	}
	
	public Produit getProduit(int i) {
		return produits.get(i);
	}

	public void setProduits(List<Produit> produits) {
		this.produits = produits;
	}
	
	public void setProduit(Produit produit) {
		this.produits.add(produit);
	}
	

	public Client getClient() {
		return client;
	}

	public void setClient(Client client) {
		this.client = client;
	}

	
	
	
	
}
