package com.camaratek.entity;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.ForeignKey;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.Table;


@Entity
@Table(name = "produit")
public class Produit implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id", nullable = false)
	private int id;
	@Column(name = "reference", length = 255, nullable = true)
	private String reference;
	@Column(name = "priceUnitaire", nullable = true)
	private float priceUnitaire;
	
	@Column(name = "description", nullable = true)
	private String description;
	
	@ManyToOne
	@JoinColumn(name = "famille_id",  foreignKey = @ForeignKey(name = "FAMILLE_ID_FK"))
	private Famille famille;
	
	@ManyToMany(cascade = CascadeType.ALL)
	@JoinTable(name = "produit_etiquette",
		joinColumns = {
				@JoinColumn(name = "produit_id")
				},
		inverseJoinColumns = {
				@JoinColumn(name = "etiquette_id")
				}
	)
	private List<Etiquette> etiquettes = new ArrayList<Etiquette>();
	
	
	
	public Produit(String reference, String description, float priceUnitaire) {
		super();
		this.reference = reference;
		this.description = description;
		this.priceUnitaire = priceUnitaire;
	}
	
	public Produit(String reference, String description, float priceUnitaire, Famille famille) {
		super();
		this.reference = reference;
		this.description = description;
		this.priceUnitaire = priceUnitaire;
		this.famille = famille;
	}
	
	
	
	
	public Produit(String reference, float priceUnitaire, String description, Famille famille,
			List<Etiquette> etiquettes) {
		super();
		this.reference = reference;
		this.priceUnitaire = priceUnitaire;
		this.description = description;
		this.famille = famille;
		this.etiquettes = etiquettes;
	}

	public Produit() {
		// TODO Auto-generated constructor stub
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getReference() {
		return reference;
	}

	public void setReference(String reference) {
		this.reference = reference;
	}

	public float getPriceUnitaire() {
		return priceUnitaire;
	}

	public void setPriceUnitaire(float priceUnitaire) {
		this.priceUnitaire = priceUnitaire;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Famille getFamille() {
		return famille;
	}

	public void setFamille(Famille famille) {
		this.famille = famille;
	}

	public List<Etiquette> getEtiquettes() {
		return this.etiquettes;
	}
	
	public Etiquette getEtiquette(int index) {
		return etiquettes.get(index);
	}

	public void setEtiquettes(List<Etiquette> etiquettes) {
		this.etiquettes = etiquettes;
	}
	
	public void setEtiquette(Etiquette etiquette) {
		this.etiquettes.add(etiquette);
	}
	
	

}
