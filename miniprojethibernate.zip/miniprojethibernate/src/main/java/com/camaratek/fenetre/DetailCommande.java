package com.camaratek.fenetre;

import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JButton;
import javax.swing.JFormattedTextField;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;


import com.camaratek.entity.Application;
import com.camaratek.entity.Client;
import com.camaratek.entity.Commande;
import com.camaratek.entity.Etiquette;
import com.camaratek.entity.Famille;
import com.camaratek.entity.Produit;

public class DetailCommande extends JFrame {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	CardLayout cl = new CardLayout();
	JPanel content = new JPanel();
	int indice = 0;
	JPanel card1;


	public List<Client> clients = new ArrayList<Client>();
	public List<Produit> produits = new ArrayList<Produit>();
	public List<Commande> commandes = new ArrayList<Commande>();
	public List<Famille> familles = new ArrayList<Famille>();
	List<Etiquette> etiquettes = new ArrayList<Etiquette>();

	public DetailCommande(final Application app,final List<Famille> familles, final List<Etiquette> etiquettes, final List<Client> clients,final List<Produit> produits, final List<Commande> commandes){
		this.setTitle("CardLayout");
		this.setSize(800, 600);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setLocationRelativeTo(null);

		this.clients = clients;
		this.produits = produits;
		this.commandes = commandes;
		this.familles = familles;
		this.etiquettes = etiquettes;


		JPanel boutonPane = new JPanel();
		JButton bouton = new JButton("Contenu suivant");
		JButton bouton3 = new JButton("Accueil");
		
		bouton3.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
				
				new Fenetre(app,familles, etiquettes, clients, produits, commandes);
			}
		});
		
		//D�finition de l'action du bouton
		bouton.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent event){
				//Via cette instruction, on passe au prochain conteneur de la pile
				cl.next(content);
			}
		});

		JButton bouton2 = new JButton("contenu precedent");
		//D�finition de l'action du bouton2
		bouton2.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent event){				
				cl.previous(content);
			}
		});
		
		boutonPane.add(bouton3);
		boutonPane.add(bouton2);
		boutonPane.add(bouton);
		//On d�finit le layout
		content.setLayout(cl);
		//On ajoute les cartes � la pile avec un nom pour les retrouver
		for(int i = 0; i < commandes.size(); i++) {
			content.add(listerCommande(i));
		}

		this.getContentPane().add(boutonPane, BorderLayout.NORTH);
		this.getContentPane().add(content, BorderLayout.CENTER);
		this.setVisible(true);
	}

	public JPanel listerCommande(int currIndex) {


		//On cr�e un conteneur avec gestion horizontale
		JPanel fr = new JPanel();
		JPanel container = new JPanel();
		container.setSize(800, 80);
		Font police = new Font("Arial", Font.BOLD, 14);

		JPanel top = new JPanel();
		fr.setLayout(new GridLayout(clients.size(), 1));


		this.setTitle("Liste des Commandes");
		this.setFont(new Font("arial black", Font.BOLD, 20));
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setLocationRelativeTo(null);

		Commande commande = commandes.get(currIndex);
		
		JPanel pan = new JPanel();
		JFormattedTextField text = new JFormattedTextField("   ID COMMANDE : " + commande.getId() + "  NOM DU CLIENT : " + commande.getClient().getNom());


		police = new Font("Arial", Font.BOLD, 14);
		text.setFont(police);
		text.setPreferredSize(new Dimension(760, 30));
		text.setForeground(Color.BLUE);

		top.add(text);
		for(int i=0; i < commande.getProduits().size(); i++)
		{
			pan = new JPanel();
			JLabel txt1 = new JLabel();
			JLabel txt2 = new JLabel();
			JLabel txt3 = new JLabel();
			JLabel txt4 = new JLabel();
			JLabel txt5 = new JLabel();

			txt1.setFont(police);
			txt1.setPreferredSize(new Dimension(760, 30));
			txt1.setForeground(Color.magenta);

			txt2.setFont(police);
			txt2.setPreferredSize(new Dimension(760, 30));
			txt2.setForeground(Color.magenta);

			txt3.setFont(police);
			txt3.setPreferredSize(new Dimension(760, 30));
			txt3.setForeground(Color.magenta);

			txt4.setFont(police);
			txt4.setPreferredSize(new Dimension(760, 30));
			txt4.setForeground(Color.magenta);

			txt5.setFont(police);
			txt5.setPreferredSize(new Dimension(760, 30));
			txt5.setForeground(Color.magenta);

			txt1.setText("============= Produit N� " + (i+1) + " : ================");
			txt2.setText("  REFERENCE : " + commande.getProduits().get(i).getReference());
			txt3.setText("  DESCRIPTION : " + commande.getProduits().get(i).getDescription());
			txt4.setText("  PRIX UNITAIRE : " + commande.getProduits().get(i).getPriceUnitaire());
			/*if(commande.getProduits().get(i) != null)
				txt5.setText("  FAMILLE NOM : " + commande.getProduits().get(i).getFamille().getNom());*/

			top.add(txt1);
			top.add(txt2);
			top.add(txt3);
			top.add(txt4);
			top.add(txt5);
		}
		top.add(pan);
		return top;
	}	



}