package com.camaratek.fenetre;


import java.util.ArrayList;
import java.util.List;

import javax.swing.* ;

import com.camaratek.entity.Application;
import com.camaratek.entity.Client;
import com.camaratek.entity.Commande;
import com.camaratek.entity.Etiquette;
import com.camaratek.entity.Famille;
import com.camaratek.entity.Produit;
public class Fenetre extends JFrame
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public List<Client> clients = new ArrayList<Client>();
	public List<Produit> produits = new ArrayList<Produit>();
	List<Commande> commandes = new ArrayList<Commande>();
	List<Famille> familles = new ArrayList<Famille>();
	List<Etiquette> etiquettes = new ArrayList<Etiquette>();
	Application app = new Application();
	

	public Fenetre(final Application app,final List<Famille> familles, final List<Etiquette> etiquettes, final List<Client> clients, final List<Produit> produits, final List<Commande> commandes) {
		this.clients = clients;
		this.produits = produits;
		this.commandes = commandes;
		this.familles = familles;
		this.etiquettes = etiquettes;
		this.app = app;

		this.setJMenuBar(new Menu(app,this.familles, this.etiquettes, this.clients, this.produits, this.commandes ,this));
		this.setSize(800,600);
		this.setTitle("Mini Projet Hibernate");
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setLocationRelativeTo(null);    
		this.setVisible(true);
	}
}