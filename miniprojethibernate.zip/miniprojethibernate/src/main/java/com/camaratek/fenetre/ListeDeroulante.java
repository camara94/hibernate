package com.camaratek.fenetre;

import java.awt.FlowLayout;

import javax.swing.JComboBox;
import javax.swing.JPanel;


public class ListeDeroulante extends JComboBox<Object> {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JComboBox<?> liste1;
	@SuppressWarnings({ "unused", "unchecked", "rawtypes" })
	private JPanel buildContentPane(){
		JPanel panel = new JPanel();
		panel.setLayout(new FlowLayout());
 
		Object[] elements = new Object[]{"Element 1", "Element 2", "Element 3", "Element 4", "Element 5"};
 
		liste1 = new JComboBox(elements);
 
		panel.add(liste1);
		return panel;
	}
 
	public JComboBox<?> getListe1(){
		return liste1;
	}
 
}