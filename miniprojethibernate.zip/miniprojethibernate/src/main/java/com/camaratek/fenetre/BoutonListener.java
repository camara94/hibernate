package com.camaratek.fenetre;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFormattedTextField;
import javax.swing.JLabel;

import com.camaratek.entity.Application;
import com.camaratek.entity.Client;


public class BoutonListener implements ActionListener {
	String itemSelected;
	Application app = new Application();
	private JFormattedTextField[] f;
	JLabel err;
	public BoutonListener(final Application app, JFormattedTextField ...f) {
		// TODO Auto-generated constructor stub
		this.f = f;
	}
	
	public BoutonListener(final Application app, String itemSelected, JFormattedTextField ...f) {
		// TODO Auto-generated constructor stub
		this.f = f;
		this.itemSelected = itemSelected;
	}
	
	public BoutonListener(final Application app, String itemSelected,JLabel err, JFormattedTextField ...f) {
		// TODO Auto-generated constructor stub
		this.f = f;
		this.itemSelected = itemSelected;
		this.err = err;
	}
	
	public BoutonListener(Application app2, JLabel err, JFormattedTextField ...f) {
		// TODO Auto-generated constructor stub
		this.f = f;
		this.err = err;
	}

	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		Client clt = new Client();
		//Ajouter client
		if (f.length == 2) {
			for(int i=0; i<f.length; i++) {
				
				if (i == 0)
					clt.setAdresse(f[i].getText());
				else
					clt.setNom(f[i].getText());
					
				//System.out.println(f[i].getText());
				
			}
			System.out.println("TEXT : " + clt.getNom());
			Application.addClient(clt);
		}
		
		
		//Supprimer client
		if (f.length == 1) {
			int id = Integer.valueOf(f[0].getText()).intValue();
			if (id > 0 && id < Application.listClients().size())
				Application.supprimerClient(id);
			else
				err.setText("Cet Identifiant n'existe pas");
			 
		}
		
		
		//Modifier Client
		if (f.length == 3) {
			clt = new Client();
			int id = 0;
			for(int i=0; i<f.length; i++) {
				if (i == 0 )
				{
					id = Integer.valueOf(f[0].getText()).intValue();
					clt.setId(id);
				}
				else if (i == 1)	
					clt.setNom(f[i].getText());
				else
					clt.setAdresse(f[i].getText());
					
					Application.updateClient(id, clt);
				
			}
		}
	}
	
	

}
