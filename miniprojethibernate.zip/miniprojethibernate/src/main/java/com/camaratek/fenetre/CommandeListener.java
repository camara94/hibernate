package com.camaratek.fenetre;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JFormattedTextField;
import javax.swing.JLabel;

import com.camaratek.entity.Application;
import com.camaratek.entity.Client;
import com.camaratek.entity.Commande;
import com.camaratek.entity.Produit;


public class CommandeListener implements ActionListener {

	Application app = new Application();
	@SuppressWarnings("unused")
	private String itemSelected;
	private JFormattedTextField[] f;
	JLabel err;
	public CommandeListener(final Application app, String itemSelected, JFormattedTextField ...f) {
		// TODO Auto-generated constructor stub
		this.f = f;
		this.itemSelected = itemSelected;
	}

	public CommandeListener(Application app2, JLabel err,  JFormattedTextField ...f) {
		// TODO Auto-generated constructor stub
		this.f = f;
		this.err = err;
	}

	public CommandeListener(Application app,  JFormattedTextField ...f) {
		// TODO Auto-generated constructor stub
		this.f = f;
	}

	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		Client client = new Client();
		Produit prod = new Produit();
		List<Produit> lp = new ArrayList<Produit>();
		Commande cmd = new Commande();

		//Ajouter Commande
		if (f.length == 2) {
			for(int i=0; i<f.length; i++) {

				if (i == 0)
				{
					client.setId(Integer.valueOf(f[i].getText()).intValue());
					System.out.println(client.getId());
				}
				else 
				{
					String str = f[i].getText();
					String[] tab = str.split(" ");

					for(int k = 0; k < Application.listClients().size(); k++)
					{
						if(Application.listClients().get(k).getId() == client.getId())
						{
							client=Application.listClients().get(k);
							cmd.setClient(client);
						}
					}
					for(int j = 0; j < tab.length; j++)
					{
						prod=Application.listProduits().get(j);
						lp.add(prod);
						cmd.setProduit(prod);			
					}
				}
			}
			Application.addCommande(cmd);
		}
		//Supprimer Commande
		if (f.length == 1) {
			int id = Integer.valueOf(f[0].getText()).intValue();
			if (id > 0 && verifyId(id, Application.listCommandes()))
				Application.supprimerCommande(id);
			else
				err.setText("Cet Identifiant n'existe pas");

		}
		//Modifier Commande
		if (f.length == 3) {
			Commande cmd1 = new Commande();
			int id = 0;
			for(int i=0; i<f.length; i++) {
				if (i == 0 )
				{
					id = Integer.valueOf(f[i].getText()).intValue();
					//cmd1.setId(id);
				}
				else if (i == 1) {
					cmd1.setClient(Application.getClient(Integer.valueOf(f[i].getText())));
					System.out.println(Application.getClient(Integer.valueOf(f[i].getText())).getNom());
				}
				else if (i == 2) {
					String str = f[i].getText();
					String[] tab = str.split(" ");

					for(int k = 0; k < tab.length; k++)
					{
						cmd1.setProduit(Application.getProduit(Integer.valueOf(tab[k]).intValue()));
						System.out.println(Application.getProduit(Integer.valueOf(tab[k]).intValue()).getReference());
					}
				}

				System.out.println(id);
				Application.updateCommande(id, cmd1);
			}
		}
	}

	public boolean verifyId(int id, List<Commande> lc) {
		boolean valeur = false;

		for(int i = 0; i < lc.size(); i++)
		{
			if(id == lc.get(i).getId())
				valeur = true;
		}
		return valeur;
	}
}
