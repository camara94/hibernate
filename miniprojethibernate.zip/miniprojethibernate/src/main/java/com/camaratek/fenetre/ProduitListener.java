package com.camaratek.fenetre;


import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JFormattedTextField;
import javax.swing.JLabel;

import com.camaratek.entity.Application;
import com.camaratek.entity.Etiquette;
import com.camaratek.entity.Produit;


public class ProduitListener implements ActionListener {

	Application app = new Application();
	@SuppressWarnings("unused")
	private int[] idFamille;
	private JFormattedTextField[] f;
	JLabel err;
	public ProduitListener(final Application app, int[] idFamille, JFormattedTextField ...f) {
		// TODO Auto-generated constructor stub
		this.f = f;
		this.idFamille = idFamille;
	}

	public ProduitListener(Application app2, JLabel err,  JFormattedTextField ...f) {
		// TODO Auto-generated constructor stub
		this.f = f;
		this.err = err;
	}


	public ProduitListener(Application app2,  JFormattedTextField ...f) {
		// TODO Auto-generated constructor stub
		this.f = f;
	}



	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		Produit prod = new Produit();
		@SuppressWarnings("unused")
		List<Etiquette> le = new ArrayList<Etiquette>();
		//Ajouter Produit
		if (f.length == 5) {
			for(int i=0; i<f.length; i++) {

				if (i == 0)
					prod.setPriceUnitaire(Float.valueOf(f[i].getText()).floatValue());
				else if(i == 1)	
					prod.setReference(f[i].getText());
				else if(i == 2)
					prod.setDescription(f[i].getText());
				else if (i == 3)
					prod.setFamille(Application.getFamille(Integer.valueOf(f[i].getText()).intValue()));
				else
				{
					String str = f[i].getText();
					String[] tab = str.split(" ");
					
					for(int k = 0; k < tab.length; k++)
					{
						prod.setEtiquette(Application.getEtiquette(Integer.valueOf(tab[k]).intValue()));

					}
				}
				
				

			}

			System.out.println("REFERENCE : " + prod.getReference());
			System.out.println("DESCRIPTION : " + prod.getDescription());
			System.out.println("PRIX UNITAIRE : " + prod.getPriceUnitaire());
			System.out.println("FAMILLE ID : " + prod.getFamille().getId() );
			for(Etiquette et: prod.getEtiquettes())
			{
				System.out.println(et.getNom());
			}
			
			Application.addProduit(prod);
		}
		
		
		//Supprimer produit
		if (f.length == 1) {
			int id = Integer.valueOf(f[0].getText()).intValue();
			if (id > 0 && verifyId(id, Application.listProduits()))
				Application.supprimerProduit(id);
			else
				err.setText("Cet Identifiant n'existe pas");

		}
		//Modifier Client
		if (f.length == 6) {
			Produit prod1 = new Produit();
			int id = 0;
			for(int i=0; i<f.length; i++) {
				if (i == 0 )
				{
					id = Integer.valueOf(f[0].getText()).intValue();
					prod1.setId(id);
				}
				else if (i == 1)	
					prod1.setDescription(f[i].getText());
				else if ( i == 2)
					prod1.setPriceUnitaire(Float.valueOf(f[i].getText()).floatValue());
				else if ( i == 3)
					prod1.setReference(f[i].getText());
				else if (i == 4)
					prod1.setFamille(Application.getFamille(Integer.valueOf(f[i].getText()).intValue()));
				else
				{
					String str = f[i].getText();
					String[] tab = str.split(" ");
					
					for(int k = 0; k < tab.length; k++)
					{
						prod1.setEtiquette(Application.getEtiquette(Integer.valueOf(tab[k]).intValue()));

					}
				}
				Application.updateProduit(id, prod1);

			}
		}
	}
	
	public boolean verifyId(int id, List<Produit> lp) {
		boolean valeur = false;
		
		for(int i = 0; i < lp.size(); i++)
		{
			if(id == lp.get(i).getId())
				valeur = true;
		}
		
		return valeur;
	}
}
