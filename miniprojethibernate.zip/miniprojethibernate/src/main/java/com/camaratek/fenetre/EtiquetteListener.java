package com.camaratek.fenetre;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFormattedTextField;
import javax.swing.JLabel;

import com.camaratek.entity.Application;
import com.camaratek.entity.Etiquette;


public class EtiquetteListener implements ActionListener {
	String itemSelected;
	Application app = new Application();
	private JFormattedTextField[] f;
	JLabel err = new JLabel();
	public EtiquetteListener(final Application app, JFormattedTextField ...f) {
		// TODO Auto-generated constructor stub
		this.f = f;
		//JLabel err = new JLabel();
	}

	public EtiquetteListener(final Application app, String itemSelected, JFormattedTextField ...f) {
		// TODO Auto-generated constructor stub
		this.f = f;
		this.itemSelected = itemSelected;
	}

	public EtiquetteListener(final Application app, String itemSelected,JLabel err, JFormattedTextField ...f) {
		// TODO Auto-generated constructor stub
		this.f = f;
		this.itemSelected = itemSelected;
		this.err = err;
	}

	public EtiquetteListener(Application app2, JLabel err, JFormattedTextField ...f) {
		// TODO Auto-generated constructor stub
		this.f = f;
		this.err = err;
	}

	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		Etiquette etiuette = new Etiquette();
		//Ajouter Etiquette
		if (f.length == 2) {
			for(int i=0; i<f.length; i++) {

				if (i == 0)
					etiuette.setCouleur(f[i].getText());
				else
					etiuette.setNom(f[i].getText());


				//System.out.println(f[i].getText());

			}
			System.out.println("TEXT : " + etiuette.getNom());
			Application.addEtiquette(etiuette);
		}


		//Supprimer Etiquette
		if (f.length == 1) {
			int id = Integer.valueOf(f[0].getText()).intValue();
			if (id > 0 && id <= Application.listEtiquettes().size())
				Application.supprimerEtiquette(id);
			else
				err.setText("Cet Identifiant n'existe pas");	 
		}


		//Modifier Etiquette
		if (f.length == 3) {

			int id = 0;
			for(int i=0; i<f.length; i++) {
				if (i == 0 )
				{
					id = Integer.valueOf(f[0].getText()).intValue();
					etiuette.setId(id);
				}
				else if (i == 1)	
					etiuette.setNom(f[i].getText());
				else
					etiuette.setCouleur(f[i].getText());

				Application.updateEtiquette(id, etiuette);

			}
		}
	}



}
