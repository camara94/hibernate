package com.camaratek.fenetre;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import javax.swing.JButton;
import javax.swing.JFormattedTextField;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;



import com.camaratek.entity.Application;
import com.camaratek.entity.Client;
import com.camaratek.entity.Commande;
import com.camaratek.entity.Etiquette;
import com.camaratek.entity.Famille;
import com.camaratek.entity.Produit;

public class Menu extends JMenuBar implements ActionListener
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public List<Famille> familles = new ArrayList<Famille>();
	public List<Client> clients = new ArrayList<Client>();
	public List<Produit> produits = new ArrayList<Produit>();
	public List<Commande> commandes = new ArrayList<Commande>();
	public List<Etiquette> etiquettes = new ArrayList<Etiquette>();
	
	Application app = new Application();
	private JFrame fr = new JFrame();
	JMenu mf ;
	JMenuItem mi1, mi11,mi22, mi2, mi3, mi4 ;
	JMenu me, mc, fam, eti ;
	JMenuItem me11,me1,me22,me2,me3, me4;
	JMenuItem mc11,mc1,mc22,mc2,mc3, mc4;
	JMenuItem fam11,fam1,fam22,fam2,fam3, fam4;
	JMenuItem eti11,eti1,eti22,eti2,eti3, eti4;
	
	//liste deroulante
	ListeDeroulante deroule;
	public Menu(final Application app,final List<Famille> familles, final List<Etiquette> etiquettes, final List<Client> clients,final List<Produit> produits, final List<Commande> commandes, final JFrame fr) {
		this.clients = clients;
		this.produits = produits;
		this.commandes = commandes;
		this.familles = familles;
		this.etiquettes = etiquettes;
		this.fr = fr;
		this.app = app;
		deroule = new ListeDeroulante();
		/****************** Familles ******************/
		fam = new JMenu("Gestion des Familles");
		fam11 = new JMenuItem("Ajouter Un Famille");
		fam22 = new JMenuItem("Modifier Un Famille");
		fam2 = new JMenuItem("Supprimer  Un Famille");
		fam3 = new JMenuItem("Liste des Familles");
		fam4 = new JMenuItem("Quitter");

		
		/****************** Etiquettes ******************/
		eti = new JMenu("Gestion des Etiquettes");
		eti11 = new JMenuItem("Ajouter Un Etiquette");
		eti22 = new JMenuItem("Modifier Un Etiquette");
		eti2 = new JMenuItem("Supprimer  Un Etiquette");
		eti3 = new JMenuItem("Liste des Etiquettes");
		eti4 = new JMenuItem("Quitter");
		
		/****************** Clients ******************/
		mf = new JMenu("Gestion des Clients");
		mi11 = new JMenuItem("Ajouter Un Client");
		mi22 = new JMenuItem("Modifier Un Client");
		mi2 = new JMenuItem("Supprimer  Un Client");
		mi3 = new JMenuItem("Liste des clients");
		mi4 = new JMenuItem("Quitter");




		//Menu de gestion des produits
		/****************** Edition ******************/
		me = new JMenu("Gestion des Produits");
		me11 = new JMenuItem("Ajouter un Produit");
		me22 = new JMenuItem("Modifier Un Produits");
		me2 = new JMenuItem("Supprimer Un Produits");
		me3 = new JMenuItem("Liste des Produits");
		me4 = new JMenuItem("Quitter");


		/****************** Clients ******************/
		mc = new JMenu("Gestion des Commande");
		mc11 = new JMenuItem("Cr�er Un Commande");
		mc22 = new JMenuItem("Modifier Sa Commande");
		mc2 = new JMenuItem("Supprimer Sa Commande");
		mc3 = new JMenuItem("Liste des Commandes");
		mc4 = new JMenuItem("Quitter");




		fam.add(fam11);
		fam.add(fam22);
		fam.add(fam2);
		fam.addSeparator(); 
		fam.add(fam3);
		this.add(fam); 
		
		eti.add(eti11);
		eti.add(eti22);
		eti.add(eti2);
		eti.addSeparator(); 
		eti.add(eti3);
		this.add(eti); 

		//Menu de gestion des client
		mf.add(mi11);
		mf.add(mi22);
		mf.add(mi2);
		mf.addSeparator(); //s�parateur entre mi2 et mi3
		mf.add(mi3);
		mf.add(mi4);
		this.add(mf); 


		me.add(me11);
		me.add(me22);
		me.add(me2);
		me.addSeparator(); 
		me.add(me3);
		this.add(me); 


		mc.add(mc11);
		mc.add(mc22);
		mc.add(mc2);
		mc.addSeparator(); 
		mc.add(mc3);
		this.add(mc); 

		/*************************************** Ajout de listener *****************************************/
		mi11.addActionListener(this);
		mi3.addActionListener(this);
		mi2.addActionListener(this);
		mi22.addActionListener(this);

		me3.addActionListener(this);
		me11.addActionListener(this);
		me2.addActionListener(this);
		me22.addActionListener(this);


		mc3.addActionListener(this);
		mc2.addActionListener(this);
		mc22.addActionListener(this);
		mc11.addActionListener(this);


		fam11.addActionListener(this);
		fam3.addActionListener(this);
		fam2.addActionListener(this);
		fam22.addActionListener(this);
		
		eti11.addActionListener(this);
		eti3.addActionListener(this);
		eti2.addActionListener(this);
		eti22.addActionListener(this);


	}


	@SuppressWarnings("unused")
	public void actionPerformed(ActionEvent ev) {
		JPanel container = new JPanel();
		container.setSize(800, 80);
		Font police = new Font("Arial", Font.BOLD, 14);

		JPanel top = new JPanel();

		/******************************************** Clients  ******************************************/
		//Lister les client
		if(ev.getSource()== mi3)
		{
			//On cr�e un conteneur avec gestion horizontale


			fr.setLayout(new GridLayout(clients.size(), 1));
			for (Iterator<Client> iterator = clients.iterator(); iterator.hasNext();)
			{


				fr.setTitle("Liste des Clients");
				fr.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				fr.setLocationRelativeTo(null);

				Client client = (Client) iterator.next();
				JFormattedTextField text = new JFormattedTextField("   ID : " + client.getId() + " ||  NOM : " + client.getNom() + " ||  Adresse : " + client.getAdresse());
				police = new Font("Arial", Font.BOLD, 14);
				text.setFont(police);
				text.setPreferredSize(new Dimension(760, 30));
				text.setForeground(Color.BLUE);
				top.add(text);
				fr.setContentPane(top);
				fr.setVisible(true);
			}



		}
		//Ajouter un client
		if(ev.getSource()== mi11)
		{
			fr.setTitle("Ajouter Un Client");
			JFormattedTextField jtf = new JFormattedTextField();
			JFormattedTextField jtf2 = new JFormattedTextField();
			JLabel label = new JLabel("Votre Nom: ");
			JLabel label2 = new JLabel("Votre Adresse: ");

			label.setPreferredSize(new Dimension(150, 30));
			label2.setPreferredSize(new Dimension(150, 30));
			JButton b = new JButton ("Ajouter Client");
			police = new Font("Arial", Font.BOLD, 14);
			jtf.setFont(police);
			jtf.setPreferredSize(new Dimension(600, 30));
			jtf.setForeground(Color.BLUE);

			jtf2.setFont(police);
			jtf2.setPreferredSize(new Dimension(600, 30));
			jtf2.setForeground(Color.BLUE);

			top.add(label);
			top.add(jtf);
			top.add(label2);
			top.add(jtf2);
			top.add(b);

			JLabel err = new JLabel();
			err.setFont(police);
			err.setForeground(Color.red);
			top.add(err);
			fr.setContentPane(top);
			fr.setVisible(true);  

			b.addActionListener(new BoutonListener(app, err, jtf2, jtf));
		}

		//Suppression de compte
		if(ev.getSource()== mi2)
		{
			fr.setTitle("Supprimer Un Client");
			JFormattedTextField jtf = new JFormattedTextField();

			JLabel label = new JLabel("Quel est  l'id du client : ");

			label.setPreferredSize(new Dimension(150, 30));

			JButton b = new JButton ("Supprimer Client");
			police = new Font("Arial", Font.BOLD, 14);
			jtf.setFont(police);
			jtf.setPreferredSize(new Dimension(600, 30));
			jtf.setForeground(Color.BLUE);
			JLabel err = new JLabel();
			err.setFont(police);
			err.setPreferredSize(new Dimension(650, 30));
			err.setForeground(Color.RED);


			top.add(label);
			top.add(jtf);


			top.add(b);
			top.add(err);
			fr.setContentPane(top);
			fr.setVisible(true);  

			b.addActionListener(new BoutonListener(app, err, jtf));
		} 

		//Modifier un Client
		if(ev.getSource()== mi22)
		{
			fr.setTitle("Modifier Un Client");
			JFormattedTextField jtf = new JFormattedTextField();
			JFormattedTextField jtf2 = new JFormattedTextField();
			JFormattedTextField jtf3 = new JFormattedTextField();
			JLabel label2 = new JLabel("Votre Nom: ");
			JLabel label3 = new JLabel("Votre Adresse: ");
			JLabel label = new JLabel("Votre id : ");

			label.setPreferredSize(new Dimension(150, 30));
			label2.setPreferredSize(new Dimension(150, 30));
			label3.setPreferredSize(new Dimension(150, 30));
			JButton b = new JButton ("Modifier Client");
			police = new Font("Arial", Font.BOLD, 14);
			jtf.setFont(police);
			jtf.setPreferredSize(new Dimension(600, 30));
			jtf.setForeground(Color.BLUE);

			jtf2.setFont(police);
			jtf2.setPreferredSize(new Dimension(600, 30));
			jtf2.setForeground(Color.BLUE);

			jtf3.setFont(police);
			jtf3.setPreferredSize(new Dimension(600, 30));
			jtf3.setForeground(Color.BLUE);

			top.add(label);
			top.add(jtf);
			top.add(label2);
			top.add(jtf2);
			top.add(label3);
			top.add(jtf3);
			top.add(b);
			fr.setContentPane(top);
			fr.setVisible(true);  

			b.addActionListener(new BoutonListener(app, jtf, jtf2, jtf3));
		}

		/******************************************** Produits  ******************************************/
		//Ajouter un produit
		if(ev.getSource()== me11)
		{
			fr.setTitle("Ajouter Un Produit");
			final JFormattedTextField jtf = new JFormattedTextField();
			final JFormattedTextField jtf2 = new JFormattedTextField();
			final JFormattedTextField jtf3 = new JFormattedTextField();
			final JFormattedTextField jtf4 = new JFormattedTextField();
			final JFormattedTextField jtf5 = new JFormattedTextField();
			JLabel label2 = new JLabel("La R�f�rence: ");
			JLabel label3 = new JLabel("La Description : ");
			JLabel label = new JLabel("Le Prix Unitaire : ");
			JLabel label4 = new JLabel("L'id de la Famille : ");
			JLabel label5 = new JLabel("Les id des �tiquettes : ");

			label.setPreferredSize(new Dimension(150, 30));
			label2.setPreferredSize(new Dimension(150, 30));
			label3.setPreferredSize(new Dimension(150, 30));
			label4.setPreferredSize(new Dimension(150, 30));
			label5.setPreferredSize(new Dimension(150, 30));
			
			final JButton b = new JButton ("Ajouter Produit");
			b.setPreferredSize(new Dimension(750, 30));
			police = new Font("Arial", Font.BOLD, 14);
			jtf.setFont(police);
			jtf.setPreferredSize(new Dimension(600, 30));
			jtf.setForeground(Color.BLUE);

			jtf2.setFont(police);
			jtf2.setPreferredSize(new Dimension(600, 30));
			jtf2.setForeground(Color.BLUE);

			jtf3.setFont(police);
			jtf3.setPreferredSize(new Dimension(600, 30));
			jtf3.setForeground(Color.BLUE);
			
			jtf4.setFont(police);
			jtf4.setPreferredSize(new Dimension(600, 30));
			jtf4.setForeground(Color.BLUE);
			
			jtf5.setFont(police);
			jtf5.setPreferredSize(new Dimension(600, 30));
			jtf5.setForeground(Color.BLUE);

			top.add(label);
			top.add(jtf);
			
			top.add(label2);
			top.add(jtf2);
			
			top.add(label3);
			top.add(jtf3);
			
			top.add(label4);
			top.add(jtf4);
			
			top.add(label5);
			top.add(jtf5);



			/*List<Famille> elements = app.listFamilles();
			String[] id = new String[elements.size()];
			for(int i = 0; i < elements.size(); i++) {
				System.out.println(product.getCategories().get(i).getName() + " ID: " + product.getCategories().get(i).getId());
				id[i] = elements.get(i).getNom();
			}


			String[] id = new String[elements.size()];
						   for(int i = 0; i < elements.size(); i++) {
								System.out.println(product.getCategories().get(i).getName() + " ID: " + product.getCategories().get(i).getId());
								id[i] = String.valueOf(elements.get(i).getId()).toString();
							}


			final String k = new String();
			final JComboBox liste1 = new JComboBox(id);

			
			liste1.addItemListener(new ItemListener() {

				public void itemStateChanged(ItemEvent e) {
					// TODO Auto-generated method stub
					//itemSelected = String.valueOf(liste1.getSelectedItem()).toString();
					String ff = e.getSource().toString().toString().substring(324, e.getSource().toString().toString().lastIndexOf("]") );
					if (liste1.getSelectedItem() == e.getSource()
					if(ff != null)
					{
						String itemSelected = String.valueOf(liste1.getSelectedItem()).toString();
						System.out.println(itemSelected);		
					}
					
					

				}
			});*/
			
			 //Integer.valueOf(jtf4.getText()).intValue();
			b.addActionListener(new ProduitListener(app, jtf, jtf2, jtf3, jtf4, jtf5));

			//liste1.setPreferredSize(new Dimension(600, 30));
			//top.add(label4);
			//top.add(liste1);
			top.add(b);
			fr.setContentPane(top);
			fr.setVisible(true);  


		}




		//Lister les Produits
		if(ev.getSource()== me3)
		{
			//On cr�e un conteneur avec gestion horizontale

			/*Box b1 = Box.createHorizontalBox();
			b1.add(new JButton("Bouton 1"));
			fr.setLayout(new GridLayout(produits.size(), 1));
			for (Iterator iterator = produits.iterator(); iterator.hasNext();)
			{


				fr.setTitle("Liste des Produits");
				fr.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				fr.setLocationRelativeTo(null);

				Produit produit = (Produit) iterator.next();
				JFormattedTextField text = new JFormattedTextField("   ID : " + produit.getId() + " ||  DESCRIPTION : " + produit.getDescription() + " ||  REFERENCE : " + produit.getReference());
				
				police = new Font("Arial", Font.BOLD, 14);
				
				
				text.setFont(police);
				text.setPreferredSize(new Dimension(760, 30));
				text.setForeground(Color.BLUE);
				top.add(text);
				JLabel txt2 = new JLabel();
				txt2.setText("Ce produit  a " + produit.getEtiquettes().size() +  " �tiquette(s): ");
				txt2.setFont(police);
				txt2.setPreferredSize(new Dimension(760, 30));
				top.add(txt2);
				if (produit.getEtiquettes().size() > 0)
				{
					for(int i = 0; i < produit.getEtiquettes().size(); i++)
					{
						JLabel txt1 = new JLabel();
						
						txt1.setText("Nom : " + produit.getEtiquettes().get(i).getNom() + " || Couleur " + produit.getEtiquettes().get(i).getCouleur());
						txt1.setFont(police);
						txt1.setPreferredSize(new Dimension(760, 30));
						top.add(txt1);
					}
				}
				fr.setContentPane(top);
				fr.setVisible(true);
			
			}*/
			@SuppressWarnings("unused")
			DetailProduit dp = new DetailProduit(new Application(), familles, etiquettes, clients, produits, commandes);



		}


		//Suppression d'un produit
		if(ev.getSource()== me2)
		{
			fr.setTitle("Supprimer Un Produit");
			JFormattedTextField jtf = new JFormattedTextField();

			JLabel label = new JLabel("Quel est  l'id du produit : ");

			label.setPreferredSize(new Dimension(150, 30));

			JButton b = new JButton ("Supprimer le produit");
			police = new Font("Arial", Font.BOLD, 14);
			jtf.setFont(police);
			jtf.setPreferredSize(new Dimension(600, 30));
			jtf.setForeground(Color.BLUE);
			JLabel err = new JLabel();
			err.setFont(police);
			err.setPreferredSize(new Dimension(650, 30));
			err.setForeground(Color.RED);



			top.add(label);
			top.add(jtf);


			top.add(b);
			top.add(err);
			fr.setContentPane(top);
			fr.setVisible(true);  

			b.addActionListener(new ProduitListener(app,err, jtf));
		} 



		//Modifier Produit
		if(ev.getSource()== me22)
		{
			fr.setTitle("Modifier Un Produit");
			JFormattedTextField jtf = new JFormattedTextField();
			JFormattedTextField jtf2 = new JFormattedTextField();
			JFormattedTextField jtf3 = new JFormattedTextField();
			JFormattedTextField jtf4 = new JFormattedTextField();
			JFormattedTextField jtf5 = new JFormattedTextField();
			JFormattedTextField jtf6 = new JFormattedTextField();
			JLabel label2 = new JLabel("Donnez le prix Unitaire du Produit : ");
			JLabel label3 = new JLabel("Donnez la Description du Produit : ");
			JLabel label = new JLabel("Donnez l'id du Produit : ");
			JLabel label4 = new JLabel("Donnez la R�ference du Produit : ");
			JLabel label5 = new JLabel("Donnez l'id de la Famille du Produit : ");
			JLabel label6 = new JLabel("Donnez les id des Etiquettes du Produit : ");

			label.setPreferredSize(new Dimension(150, 30));
			label2.setPreferredSize(new Dimension(150, 30));
			label3.setPreferredSize(new Dimension(150, 30));
			label4.setPreferredSize(new Dimension(150, 30));
			label5.setPreferredSize(new Dimension(150, 30));
			label6.setPreferredSize(new Dimension(150, 30));
			
			JButton b = new JButton ("Modifier Produit");
			police = new Font("Arial", Font.BOLD, 14);
			jtf.setFont(police);
			jtf.setPreferredSize(new Dimension(600, 30));
			jtf.setForeground(Color.BLUE);

			jtf2.setFont(police);
			jtf2.setPreferredSize(new Dimension(600, 30));
			jtf2.setForeground(Color.BLUE);

			jtf3.setFont(police);
			jtf3.setPreferredSize(new Dimension(600, 30));
			jtf3.setForeground(Color.BLUE);

			jtf4.setFont(police);
			jtf4.setPreferredSize(new Dimension(600, 30));
			jtf4.setForeground(Color.BLUE);
			
			jtf5.setFont(police);
			jtf5.setPreferredSize(new Dimension(600, 30));
			jtf5.setForeground(Color.BLUE);
			
			jtf6.setFont(police);
			jtf6.setPreferredSize(new Dimension(600, 30));
			jtf6.setForeground(Color.BLUE);

			top.add(label);
			top.add(jtf);
			top.add(label2);
			top.add(jtf2);
			top.add(label3);
			top.add(jtf3);
			top.add(label4);
			top.add(jtf4);
			top.add(label5);
			top.add(jtf5);
			top.add(label6);
			top.add(jtf6);
			top.add(b);
			fr.setContentPane(top);
			fr.setVisible(true);  

			b.addActionListener(new ProduitListener(app, jtf, jtf3, jtf2, jtf4,jtf5, jtf6));
		}


		/******************************************************** Commande *********************************************************/
		//Lister les Commandes
		if(ev.getSource()== mc3)
		{
			DetailCommande cv = new DetailCommande(new Application(), familles, etiquettes, clients, produits, commandes);
		}

		//Ajouter une Commande

		if (ev.getSource() == mc11) {
			fr.setTitle("Ajouter Une Commande");
			final JFormattedTextField jtf2 = new JFormattedTextField();
			final JFormattedTextField jtf3 = new JFormattedTextField();
			JLabel label2 = new JLabel("L'id du client : ");
			JLabel label3 = new JLabel("Les id des produits : ");


			label2.setPreferredSize(new Dimension(150, 30));
			label3.setPreferredSize(new Dimension(150, 30));
			final JButton b = new JButton ("Ajouter Une Commande");
			b.setPreferredSize(new Dimension(750, 30));
			police = new Font("Arial", Font.BOLD, 14);


			jtf2.setFont(police);
			jtf2.setPreferredSize(new Dimension(600, 30));
			jtf2.setForeground(Color.BLUE);

			jtf3.setFont(police);
			jtf3.setPreferredSize(new Dimension(600, 30));
			jtf3.setForeground(Color.BLUE);

			top.add(label2);
			top.add(jtf2);
			top.add(label3);
			top.add(jtf3);


			top.add(b);

			b.addActionListener(new CommandeListener(new Application(), jtf2, jtf3));

			fr.setContentPane(top);
			fr.setVisible(true);  
		}
		
		
		//Suppression d'un produit
		if(ev.getSource()== mc2)
		{
			fr.setTitle("Supprimer Une Commande");
			JFormattedTextField jtf = new JFormattedTextField();

			JLabel label = new JLabel("Quel est  l'id de la Commande : ");

			label.setPreferredSize(new Dimension(150, 30));

			JButton b = new JButton ("Supprimer Commande");
			police = new Font("Arial", Font.BOLD, 14);
			jtf.setFont(police);
			jtf.setPreferredSize(new Dimension(600, 30));
			jtf.setForeground(Color.BLUE);
			JLabel err = new JLabel();
			err.setFont(police);
			err.setPreferredSize(new Dimension(650, 30));
			err.setForeground(Color.RED);



			top.add(label);
			top.add(jtf);


			top.add(b);
			top.add(err);
			fr.setContentPane(top);
			fr.setVisible(true);  

			b.addActionListener(new CommandeListener(app,err, jtf));
		} 


		
		//Modifier un Commande
		if(ev.getSource()== mc22)
		{
			fr.setTitle("Modifier Un Commande");
			JFormattedTextField jtf = new JFormattedTextField();
			JFormattedTextField jtf2 = new JFormattedTextField();
			JFormattedTextField jtf3 = new JFormattedTextField();
			JLabel label2 = new JLabel("L'ID CLIENT: ");
			JLabel label3 = new JLabel("LES ID Commande PRODUITS : ");
			JLabel label = new JLabel("L'ID PRODUIT COMMANDE : ");

			label.setPreferredSize(new Dimension(150, 30));
			label2.setPreferredSize(new Dimension(150, 30));
			label3.setPreferredSize(new Dimension(150, 30));
			JButton b = new JButton ("Modifier Commande");
			police = new Font("Arial", Font.BOLD, 14);
			jtf.setFont(police);
			jtf.setPreferredSize(new Dimension(600, 30));
			jtf.setForeground(Color.BLUE);

			jtf2.setFont(police);
			jtf2.setPreferredSize(new Dimension(600, 30));
			jtf2.setForeground(Color.BLUE);

			jtf3.setFont(police);
			jtf3.setPreferredSize(new Dimension(600, 30));
			jtf3.setForeground(Color.BLUE);

			top.add(label);
			top.add(jtf);
			top.add(label2);
			top.add(jtf2);
			top.add(label3);
			top.add(jtf3);
			top.add(b);
			fr.setContentPane(top);
			fr.setVisible(true);  

			b.addActionListener(new CommandeListener(app, jtf, jtf2, jtf3));
		}



		/********************************** Famille ******************************************/
		//Ajouter une famille
		if(ev.getSource()== fam11)
		{
			fr.setTitle("Ajouter Une Famille de Produit");
			JFormattedTextField jtf = new JFormattedTextField();
			JFormattedTextField jtf2 = new JFormattedTextField();
			JLabel label = new JLabel("Nom: ");
			JLabel label2 = new JLabel("Description : ");

			label.setPreferredSize(new Dimension(150, 30));
			label2.setPreferredSize(new Dimension(150, 30));
			JButton b = new JButton ("Ajouter Famille");
			police = new Font("Arial", Font.BOLD, 14);
			jtf.setFont(police);
			jtf.setPreferredSize(new Dimension(600, 30));
			jtf.setForeground(Color.BLUE);

			jtf2.setFont(police);
			jtf2.setPreferredSize(new Dimension(600, 30));
			jtf2.setForeground(Color.BLUE);

			top.add(label);
			top.add(jtf);
			top.add(label2);
			top.add(jtf2);
			top.add(b);

			JLabel err = new JLabel();
			err.setFont(police);
			err.setForeground(Color.red);
			top.add(err);
			fr.setContentPane(top);
			fr.setVisible(true);  

			b.addActionListener(new FamilleListener(app, err, jtf2, jtf));
		}
		
		
		//Lister les Famille
		if(ev.getSource()== fam3)
		{
			//On cr�e un conteneur avec gestion horizontale

			System.out.println("Bonjour tout le monde ! taille : " + familles.size());
			fr.setLayout(new GridLayout(familles.size(), 1));
			for (Iterator<Famille> iterator = familles.iterator(); iterator.hasNext();)
			{


				fr.setTitle("Liste des Familles");
				fr.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				fr.setLocationRelativeTo(null);

				Famille famille = (Famille) iterator.next();
				JFormattedTextField text = new JFormattedTextField("   ID : " + famille.getId() + " ||  NOM : " + famille.getNom() + " ||  DESCRIPTION : " + famille.getDescription());
				police = new Font("Arial", Font.BOLD, 14);
				text.setFont(police);
				text.setPreferredSize(new Dimension(760, 30));
				text.setForeground(Color.BLUE);
				top.add(text);
				fr.setContentPane(top);
				fr.setVisible(true);
			}
		}
		
		
		//Suppression d'une famille
		if(ev.getSource()== fam2)
		{
			fr.setTitle("Supprimer Une Famille");
			JFormattedTextField jtf = new JFormattedTextField();

			JLabel label = new JLabel("Quel est  l'id de la Famille : ");

			label.setPreferredSize(new Dimension(150, 30));

			JButton b = new JButton ("Supprimer Famille");
			police = new Font("Arial", Font.BOLD, 14);
			jtf.setFont(police);
			jtf.setPreferredSize(new Dimension(600, 30));
			jtf.setForeground(Color.BLUE);
			JLabel err = new JLabel();
			err.setFont(police);
			err.setPreferredSize(new Dimension(650, 30));
			err.setForeground(Color.RED);


			top.add(label);
			top.add(jtf);


			top.add(b);
			top.add(err);
			fr.setContentPane(top);
			fr.setVisible(true);  

			b.addActionListener(new FamilleListener(app,err, jtf));
		} 
		
		
		
		//Modifier Une Famille
		if(ev.getSource()== fam22)
		{
			fr.setTitle("Modifier Une Famille");
			JFormattedTextField jtf = new JFormattedTextField();
			JFormattedTextField jtf2 = new JFormattedTextField();
			JFormattedTextField jtf3 = new JFormattedTextField();
			JLabel label2 = new JLabel("Nom Famille: ");
			JLabel label3 = new JLabel("Description Famille: ");
			JLabel label = new JLabel("id Famille : ");

			label.setPreferredSize(new Dimension(150, 30));
			label2.setPreferredSize(new Dimension(150, 30));
			label3.setPreferredSize(new Dimension(150, 30));
			JButton b = new JButton ("Modifier Famille");
			police = new Font("Arial", Font.BOLD, 14);
			jtf.setFont(police);
			jtf.setPreferredSize(new Dimension(600, 30));
			jtf.setForeground(Color.BLUE);

			jtf2.setFont(police);
			jtf2.setPreferredSize(new Dimension(600, 30));
			jtf2.setForeground(Color.BLUE);

			jtf3.setFont(police);
			jtf3.setPreferredSize(new Dimension(600, 30));
			jtf3.setForeground(Color.BLUE);

			top.add(label);
			top.add(jtf);
			top.add(label2);
			top.add(jtf2);
			top.add(label3);
			top.add(jtf3);
			top.add(b);
			fr.setContentPane(top);
			fr.setVisible(true);  

			b.addActionListener(new FamilleListener(app, jtf, jtf2, jtf3));
		}

		
		

		/********************************** Etiquette ******************************************/
		//Ajouter une Etiquette
		if(ev.getSource()== eti11)
		{
			fr.setTitle("Ajouter Une Etiquette de Produit");
			JFormattedTextField jtf = new JFormattedTextField();
			JFormattedTextField jtf2 = new JFormattedTextField();
			JLabel label = new JLabel("Nom: ");
			JLabel label2 = new JLabel("Couleur : ");

			label.setPreferredSize(new Dimension(150, 30));
			label2.setPreferredSize(new Dimension(150, 30));
			JButton b = new JButton ("Ajouter Etiquette");
			police = new Font("Arial", Font.BOLD, 14);
			jtf.setFont(police);
			jtf.setPreferredSize(new Dimension(600, 30));
			jtf.setForeground(Color.BLUE);

			jtf2.setFont(police);
			jtf2.setPreferredSize(new Dimension(600, 30));
			jtf2.setForeground(Color.BLUE);

			top.add(label);
			top.add(jtf);
			top.add(label2);
			top.add(jtf2);
			top.add(b);

			JLabel err = new JLabel();
			err.setFont(police);
			err.setForeground(Color.red);
			top.add(err);
			fr.setContentPane(top);
			fr.setVisible(true);  

			b.addActionListener(new EtiquetteListener(app, err, jtf2, jtf));
		}
		
		
		
		//Lister les Etiquettes
		if(ev.getSource()== eti3)
		{
			//On cr�e un conteneur avec gestion horizontale

			System.out.println("Bonjour tout le monde ! taille : " + etiquettes.size());
			fr.setLayout(new GridLayout(etiquettes.size(), 1));
			for (Iterator<Etiquette> iterator = etiquettes.iterator(); iterator.hasNext();)
			{


				fr.setTitle("Liste des Etiquettes");
				fr.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				fr.setLocationRelativeTo(null);

				Etiquette etiquette = (Etiquette) iterator.next();
				JFormattedTextField text = new JFormattedTextField("   ID : " + etiquette.getId() + " ||  NOM : " + etiquette.getNom() + " ||  COULEUR : " + etiquette.getCouleur());
				police = new Font("Arial", Font.BOLD, 14);
				text.setFont(police);
				text.setPreferredSize(new Dimension(760, 30));
				text.setForeground(Color.BLUE);
				top.add(text);
				fr.setContentPane(top);
				fr.setVisible(true);
			}
		}

		
		

		//Suppression d'�tiquette
		if(ev.getSource()== eti2)
		{
			fr.setTitle("Supprimer Une Etiquette");
			JFormattedTextField jtf = new JFormattedTextField();

			JLabel label = new JLabel("Quel est  l'id de l'Etiquette : ");

			label.setPreferredSize(new Dimension(150, 30));

			JButton b = new JButton ("Supprimer Etiquette");
			police = new Font("Arial", Font.BOLD, 14);
			jtf.setFont(police);
			jtf.setPreferredSize(new Dimension(600, 30));
			jtf.setForeground(Color.BLUE);
			JLabel err = new JLabel();
			err.setFont(police);
			err.setPreferredSize(new Dimension(650, 30));
			err.setForeground(Color.RED);


			top.add(label);
			top.add(jtf);


			top.add(b);
			top.add(err);
			fr.setContentPane(top);
			fr.setVisible(true);  

			b.addActionListener(new EtiquetteListener(app,err, jtf));
		} 
		
		
		//Modifier Une Etiquette
		if(ev.getSource()== eti22)
		{
			fr.setTitle("Modifier Une Etiquette");
			JFormattedTextField jtf = new JFormattedTextField();
			JFormattedTextField jtf2 = new JFormattedTextField();
			JFormattedTextField jtf3 = new JFormattedTextField();
			JLabel label2 = new JLabel("Nom d'Etiquette: ");
			JLabel label3 = new JLabel("Couleur d'Etiquette: ");
			JLabel label = new JLabel("id d'Etiquette : ");

			label.setPreferredSize(new Dimension(150, 30));
			label2.setPreferredSize(new Dimension(150, 30));
			label3.setPreferredSize(new Dimension(150, 30));
			JButton b = new JButton ("Modifier Etiquette");
			police = new Font("Arial", Font.BOLD, 14);
			jtf.setFont(police);
			jtf.setPreferredSize(new Dimension(600, 30));
			jtf.setForeground(Color.BLUE);

			jtf2.setFont(police);
			jtf2.setPreferredSize(new Dimension(600, 30));
			jtf2.setForeground(Color.BLUE);

			jtf3.setFont(police);
			jtf3.setPreferredSize(new Dimension(600, 30));
			jtf3.setForeground(Color.BLUE);

			top.add(label);
			top.add(jtf);
			top.add(label2);
			top.add(jtf2);
			top.add(label3);
			top.add(jtf3);
			top.add(b);
			fr.setContentPane(top);
			fr.setVisible(true);  

			b.addActionListener(new EtiquetteListener(app, jtf, jtf2, jtf3));
		}


	}

}

