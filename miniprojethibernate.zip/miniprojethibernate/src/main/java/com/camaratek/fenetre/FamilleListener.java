package com.camaratek.fenetre;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

import javax.swing.JFormattedTextField;
import javax.swing.JLabel;

import com.camaratek.entity.Application;
import com.camaratek.entity.Famille;



public class FamilleListener implements ActionListener {
	String itemSelected;
	Application app = new Application();
	private JFormattedTextField[] f;
	JLabel err;
	public FamilleListener(final Application app, JFormattedTextField ...f) {
		// TODO Auto-generated constructor stub
		this.f = f;
	}
	
	public FamilleListener(final Application app, String itemSelected, JFormattedTextField ...f) {
		// TODO Auto-generated constructor stub
		this.f = f;
		this.itemSelected = itemSelected;
	}
	
	public FamilleListener(final Application app, JLabel err2,JFormattedTextField jtf2, JFormattedTextField ...jtf) {
		// TODO Auto-generated constructor stub
		this.f = jtf;
		this.err = err2;
	}
	
	public FamilleListener(Application app2, JLabel err, String itemSelected, JFormattedTextField ...f) {
		// TODO Auto-generated constructor stub
		this.f = f;
		this.itemSelected = itemSelected;
		this.err = err;
	}

	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		Famille fam = new Famille();
		//Ajouter Famille
		if (f.length == 2) {
			for(int i=0; i<f.length; i++) {
				
				if (i == 0)
					fam.setDescription(f[i].getText());
				else
					fam.setNom(f[i].getText());	
			}
			System.out.println("TEXT : " + fam.getNom());
			Application.addFamille(fam);
		}
		
		//Supprimer Famille
		if (f.length == 1) {
			int id = Integer.valueOf(f[0].getText()).intValue();
			if (id > 0 && verifyId(id, Application.listFamilles()))
				Application.supprimerFamille(id);
			else
				err.setText("Cet Identifiant n'existe pas");	 
		}
		
		//Modifier Famille
		if (f.length == 3) {
			//Famille fam = new Famille();
			int id = 0;
			for(int i=0; i<f.length; i++) {
				if (i == 0 )
				{
					id = Integer.valueOf(f[0].getText()).intValue();
					fam.setId(id);
				}
				else if (i == 1)	
					fam.setNom(f[i].getText());
				else
					fam.setDescription(f[i].getText());
					
					Application.updateFamille(id, fam);
			}
		}
	}
	
	public boolean verifyId(int id, List<Famille> lc) {
		boolean valeur = false;
		
		for(int i = 0; i < lc.size(); i++)
		{
			if(id == lc.get(i).getId())
				valeur = true;
		}
		
		return valeur;
	}
}
